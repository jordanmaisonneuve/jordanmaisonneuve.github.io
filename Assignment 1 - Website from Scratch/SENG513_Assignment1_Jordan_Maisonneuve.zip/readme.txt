Jordan Maisonneuve
10153260
Lab Section B05 Alabood

The url for the website is https://jordanmaisonneuve.github.io

This website was tested with chrome and firefox browsers.